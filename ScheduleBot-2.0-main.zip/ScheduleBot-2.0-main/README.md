# SsheduleBot-2.0

Worker bot => https://t.me/GreatScheduleBot